<!DOCTYPE html>
<html>
<head>
	<title>Laravel Update Form Data Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
<body>
	<div class="container mt-5">
		<div class="row">
			<div class="col-md-12">
				
				<form action="<?php echo e(url('update-record')); ?>" method="post" accept-charset="utf-8"><?php echo csrf_field(); ?>

					<input type="hidden" class="form-control" name="id" value="<?php echo e($post->id); ?>">

					<div class="form-group">
						<label class="control-label col-sm-2" for="fname">Title</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" placeholder="Enter Title" name="title" value="<?php echo e($post->title); ?>">
							<span class="text-danger"><?php echo e($errors->first('title')); ?></span>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="comment">Description</label>
						<div class="col-sm-10">
							<textarea class="form-control" rows="5" name="description"><?php echo e($post->description); ?></textarea>
							<span class="text-danger"><?php echo e($errors->first('description')); ?></span>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-success">Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html><?php /**PATH C:\xampps\htdocs\Laravel-Crud-App\resources\views/edit.blade.php ENDPATH**/ ?>